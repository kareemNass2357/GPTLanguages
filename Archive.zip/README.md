# React Jobs Project (YouTube)

This is the jobs listing project from the [YouTube crash course](https://youtu.be/LDB4uaJ87e0).

<img src="public/screen.png" />

## Usage

This project uses JSON-Server for a mock backend.

### Install Dependencies

```bash
npm init -y              (so we can have things installed locally)
npm install
```

### Run JSON Server

The server will run on http://localhost:8000

```bash
npm run server
```

### Run Vite Frontend

React will run on http://localhost:3000

```bash
npm run dev
```

### Build for Production

```bash
npm run build
```

### Preview Production Build

```bash
npm run preview
```



pcb: i want to go 1 element after the other improve them
then; have selectedTransltion component handling all the cliekd on ---> let this handle the sleection as well (not the translation component)