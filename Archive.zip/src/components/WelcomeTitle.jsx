const WelcomeTitle = () => {
  return (
    <h2>Welcome to my page</h2>
  );
};

export default WelcomeTitle;
